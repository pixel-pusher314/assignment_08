#------------------------------------------#
# Title: Assignmen08.py
# Desc: Assignnment 08 - Working with classes
# Change Log: (Who, When, What)
# DBiesinger, 2030-Jan-01, created file
# DBiesinger, 2030-Jan-01, added pseudocode to complete assignment 08
# DDefelici, 2021-Dec-05, added code to pseudocode and completed TODO's
#------------------------------------------#

import pickle

# -- DATA -- #
strFileName = 'cdInventory.txt'
lstOfCDObjects = []

class CD:
    """Stores data about a CD:

    properties:
        cd_id: (int) with CD ID
        cd_title: (string) with the title of the CD
        cd_artist: (string) with the artist of the CD
    methods:

    """

    # -- Constructor -- #
    def __init__(self, id, strTitle, strArtist):
        self.__cd_id = id
        self.__cd_title = strTitle
        self.__cd_artist = strArtist
    
    # -- Properties --#
    @property
    def cd_id(self):
        return self.__cd_id
    @property
    def cd_title(self):
        return self.__cd_title
    @property
    def cd_artist(self):
        return self.__cd_artist

    @cd_id.setter
    def cd_id(self, value):
        self.__cd_id = value

    @cd_title.setter
    def cd_title(self, value):
        self.__cd_title = value    
    
    @cd_artist.setter
    def cd_artist(self, value):
        self.__cd_artist = value

# -- PROCESSING -- #
class FileIO:
    """Processes data to and from file:

    properties:

    methods:
        save_inventory(file_name, lst_Inventory): -> None
        load_inventory(file_name): -> (a list of CD objects)

    """

    @staticmethod
    def load_inventory(file_name):
        """Function to manage data ingestion from file to a list of CD objects

        Reads the data from file identified by file_name into a 2D table
        (list of CD objects)

        Args:
            file_name (string): name of file used to read the data from

        Returns:
            table (list of CD objects): 2D data structure (list of objects) that holds the data during runtime
        """

        with open(file_name, 'rb') as objFile: # Opening file to read as binary data
            return pickle.load(objFile) # Using pickle to read binary data


    @staticmethod
    def save_inventory(file_name, lst_Inventory):
        """Function to manage data ingestion to file of a list of CD objects

        Writes the data to the file identified by file_name from a 2D table
        (list of CD objects) 

        Args:
            file_name (string): name of file used to write the data to
            lst_Inventory (list of CD objects): 2D data structure (list of CD objects) that holds the data during runtime

        Returns:
            None.
        """

        with open(file_name, 'wb') as objFile: # Opening file to write binary data
            pickle.dump(lst_Inventory, objFile) # Using pickle to write binary data
    pass

# -- PRESENTATION (Input/Output) -- #
class IO:
    """Handling Input / Output"""

    @staticmethod
    def print_menu():
        """Displays a menu of choices to the user

        Args:
            None.

        Returns:
            None.
        """

        print('Menu\n\n[l] load Inventory from file\n[a] Add CD\n[i] Display Current Inventory')
        print('[s] Save Inventory to file\n[x] exit\n')

    @staticmethod
    def menu_choice():
        """Gets user input for menu selection

        Args:
            None.

        Returns:
            choice (string): a lower case sting of the users input out of the choices l, a, i, s or x

        """
        choice = ' '
        while choice not in ['l', 'a', 'i', 's', 'x']:
            choice = input('Which operation would you like to perform? [l, a, i, s or x]: ').lower().strip()
        print()  # Add extra space for layout
        return choice

    @staticmethod
    def show_inventory(table):
        """Displays current inventory table


        Args:
            table (list of CD objects): that holds the data during runtime.

        Returns:
            None.

        """
        print('======= The Current Inventory: =======')
        print('ID\tCD Title (by: Artist)\n')
        for cd in table:
            print(str(cd.cd_id) + '\t' + cd.cd_title + ' (by:' + cd.cd_artist + ')')
        print('======================================')

    @staticmethod
    def get_CD():
        """Get data for CD from input

        Args:
            None.

        Returns:
            cd (tuple): (ID, Title, Artist)

        """        
        while True:
            try:
                id = int(input('Enter a numerical ID: ').strip())
                break # breaks out of loop if the input is valid
            except:
                print('That is not a number')
        strTitle = input('What is the CD\'s title? ').strip()
        strArtist = input('What is the Artist\'s name? ').strip()
        return CD(id, strTitle, strArtist)    


# -- Main Body of Script -- #

# Load data from file into a list of CD objects on script start
try:
    lstOfCDObjects = FileIO.load_inventory(strFileName)
except:
    print('Couldn\'t find ' + strFileName) # Prints error if can't find file
# Display menu to user
while True:
    # Display Menu to user and get choice
    IO.print_menu()
    strChoice = IO.menu_choice()

    # show user current inventory
    if strChoice == 'i':
        IO.show_inventory(lstOfCDObjects)
        continue  # start loop back at top.
    
    elif strChoice == 'a': # let user add data to the inventory
        # Ask user for new ID, CD Title and Artist
        cd = IO.get_CD()

        lstOfCDObjects.append(cd) # Add item to the table
        IO.show_inventory(lstOfCDObjects)
        continue  # start loop back at top.
    # let user save inventory to file
    elif strChoice == 's':
        # Display current inventory and ask user for confirmation to save
        IO.show_inventory(lstOfCDObjects)
        strYesNo = input('Save this inventory to file? [y/n] ').strip().lower()
        # Process choice
        if strYesNo == 'y':
            # save data
            FileIO.save_inventory(strFileName, lstOfCDObjects)
        else:
            input('The inventory was NOT saved to file. Press [ENTER] to return to the menu.')
        continue  # start loop back at top.

    # let user load inventory from file
    if strChoice == 'l':
        print('WARNING: If you continue, all unsaved data will be lost and the Inventory re-loaded from file.')
        strYesNo = input('type \'yes\' to continue and reload from file. otherwise reload will be canceled: ')
        if strYesNo.lower() == 'yes':
            print('reloading...')
            try:
               lstOfCDObjects = FileIO.load_inventory(strFileName)
            except Exception as e:
                print(e)
                print('Couldn\'t find ' + strFileName)
                continue # start loop back at top if no inventory is found
            IO.show_inventory(lstOfCDObjects)
        else:
            input('canceling... Inventory data NOT reloaded. Press [ENTER] to continue to the menu.')
            IO.show_inventory(lstOfCDObjects)
        continue  # start loop back at top.
    elif strChoice == 'x': # process exit
        break
    else:
        print('General Error')